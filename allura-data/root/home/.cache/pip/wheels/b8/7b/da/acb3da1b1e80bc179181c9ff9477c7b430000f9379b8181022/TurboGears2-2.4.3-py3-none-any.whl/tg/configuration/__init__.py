from .tgconfig import config
from .app_config import AppConfig