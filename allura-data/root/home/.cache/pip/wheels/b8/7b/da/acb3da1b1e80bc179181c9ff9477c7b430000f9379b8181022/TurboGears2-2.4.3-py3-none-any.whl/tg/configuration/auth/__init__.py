from tg.configuration.auth.setup import setup_auth, _AuthenticationForgerPlugin
from tg.configuration.auth.metadata import TGAuthMetadata, create_default_authenticator